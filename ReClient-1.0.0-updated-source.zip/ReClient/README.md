# ReClient 1.0.0 source

Fabric client source project for Minecraft Java 1.21.1 (Java 21).

Changes in this source refresh:
- Removed the broken GuiMixin/Crosshair Indicator injection.
- Added an About tab with a button to open the 4Repeat YouTube channel.
- Preserved the existing module source and settings.

Build from this folder with `./gradlew clean build` (Linux/Codespaces) or `gradlew.bat clean build` (Windows).

Important: this is source code, not a precompiled JAR. The build and in-game behavior must be verified in your environment. Existing overlay and crystal-related options may still need implementation/testing; they are not claimed as fixed by this source refresh.
