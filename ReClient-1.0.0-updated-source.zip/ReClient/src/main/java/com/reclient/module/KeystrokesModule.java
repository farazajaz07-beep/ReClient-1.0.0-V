package com.reclient.module;

import com.reclient.Stats;
import com.reclient.Theme;
import com.reclient.setting.BoolSetting;
import com.reclient.ui.UI;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

public class KeystrokesModule extends HudModule {
	private final float[] anim = new float[7];
	private final BoolSetting mouse = bool("Mouse Buttons", true);
	private final BoolSetting space = bool("Space Bar", true);

	public KeystrokesModule(int x, int y) {
		super("Keystrokes", "Animated WASD, jump and mouse buttons.", x, y);
	}

	@Override
	protected boolean hasPanel() {
		return false;
	}

	@Override
	protected int contentWidth(Minecraft mc, Font font) {
		return 64;
	}

	@Override
	protected int contentHeight(Minecraft mc, Font font) {
		int h = 42;
		if (mouse.value) h += 22;
		if (space.value) h += 12;
		return h;
	}

	@Override
	protected void drawContent(GuiGraphics g, Minecraft mc, Font font, int w, int h) {
		var o = mc.options;
		key(g, font, 0, o.keyUp.isDown(), 22, 0, 20, 20, "W", null);
		key(g, font, 1, o.keyLeft.isDown(), 0, 22, 20, 20, "A", null);
		key(g, font, 2, o.keyDown.isDown(), 22, 22, 20, 20, "S", null);
		key(g, font, 3, o.keyRight.isDown(), 44, 22, 20, 20, "D", null);
		int y = 44;
		if (mouse.value) {
			key(g, font, 4, Stats.leftDown(), 0, y, 31, 20, "LMB", Stats.cpsLeft() + " CPS");
			key(g, font, 5, Stats.rightDown(), 33, y, 31, 20, "RMB", Stats.cpsRight() + " CPS");
			y += 22;
		}
		if (space.value) {
			key(g, font, 6, o.keyJump.isDown(), 0, y, 64, 10, null, null);
		}
	}

	private void key(GuiGraphics g, Font font, int i, boolean down, int x, int y, int w, int h, String label, String sub) {
		anim[i] += ((down ? 1f : 0f) - anim[i]) * Math.min(1f, Stats.dt() * 20f);
		int bg = UI.lerpColor(Theme.panel(), UI.alpha(Theme.accent(), 0.85f), anim[i]);
		UI.roundRect(g, x, y, w, h, Theme.radius, bg);
		int fg = UI.lerpColor(0xFFFFFFFF, 0xFF101114, anim[i]);
		if (label == null) {
			g.fill(x + w / 2 - 8, y + h / 2 - 1, x + w / 2 + 8, y + h / 2 + 1, fg);
		} else if (sub == null) {
			g.drawString(font, label, x + (w - font.width(label)) / 2, y + (h - 8) / 2, fg, false);
		} else {
			g.drawString(font, label, x + (w - font.width(label)) / 2, y + 3, fg, false);
			g.pose().pushPose();
			float s = 0.7f;
			float sw = font.width(sub) * s;
			g.pose().translate(x + (w - sw) / 2f, (float) (y + 12), 0f);
			g.pose().scale(s, s, 1f);
			g.drawString(font, sub, 0, 0, UI.lerpColor(0xFFA0A6B4, 0xFF101114, anim[i]), false);
			g.pose().popPose();
		}
	}
}
