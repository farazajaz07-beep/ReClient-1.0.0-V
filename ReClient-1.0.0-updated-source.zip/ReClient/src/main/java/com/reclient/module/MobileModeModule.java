package com.reclient.module;

import com.reclient.ReConfig;
import com.reclient.setting.SliderSetting;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleStatus;
import net.minecraft.client.Options;

/** One-shot low-render preset intended for Android/low-end devices. */
public final class MobileModeModule extends Module {
    private final SliderSetting renderDistance = slider("Render Distance", 5, 4, 8, 1);
    private final SliderSetting simulationDistance = slider("Simulation Distance", 4, 4, 6, 1);
    private final SliderSetting guiScale = slider("GUI Scale (1-5)", 4, 1, 5, 1);
    private final SliderSetting fpsLimit = slider("FPS Limit", 60, 30, 120, 15);
    private boolean applied;

    public MobileModeModule() {
        super("Mobile Mode", "Applies a low-render, low-particle preset for Android and low-end devices.", Category.UTILITY);
    }

    @Override
    public void onEnable() {
        applied = false;
    }

    @Override
    public void onDisable() {
        applied = false;
    }

    @Override
    public void tick(Minecraft mc) {
        if (applied || mc.player == null) return;
        Options o = mc.options;
        o.renderDistance().set(renderDistance.asInt());
        o.simulationDistance().set(simulationDistance.asInt());
        o.graphicsMode().set(GraphicsStatus.FAST);
        o.particles().set(ParticleStatus.MINIMAL);
        o.cloudStatus().set(CloudStatus.OFF);
        o.ambientOcclusion().set(false);
        o.entityShadows().set(false);
        o.entityDistanceScaling().set(0.5);
        o.biomeBlendRadius().set(0);
        o.enableVsync().set(false);
        o.framerateLimit().set(fpsLimit.asInt());
        // GUI scale is bounded by Minecraft/window capabilities; the game may clamp this value.
        o.guiScale().set(guiScale.asInt());
        o.save();
        applied = true;
        ReConfig.save();
    }
}
