package com.reclient.module;

import com.reclient.Theme;
import com.reclient.setting.BoolSetting;
import com.reclient.ui.UI;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** A draggable, scalable element drawn on the in-game HUD. */
public abstract class HudModule extends Module {
	public int x, y;
	public final int defX, defY;
	public float scale = 1f;
	/** Size (unscaled) from the last render; used for hit-testing in the HUD editor. */
	public int lastW = 40, lastH = 14;

	protected boolean editing;
	protected final BoolSetting background = bool("Background", true);

	protected HudModule(String name, String description, int x, int y) {
		super(name, description, Category.HUD);
		this.x = this.defX = x;
		this.y = this.defY = y;
	}

	protected boolean hasPanel() {
		return true;
	}

	protected abstract int contentWidth(Minecraft mc, Font font);

	protected abstract int contentHeight(Minecraft mc, Font font);

	protected abstract void drawContent(GuiGraphics g, Minecraft mc, Font font, int w, int h);

	public void resetPosition() {
		x = defX;
		y = defY;
		scale = 1f;
	}

	public void render(GuiGraphics g, Minecraft mc, boolean editing) {
		this.editing = editing;
		Font font = mc.font;
		int cw = contentWidth(mc, font);
		int ch = contentHeight(mc, font);
		if (cw <= 0 || ch <= 0) {
			lastW = 0;
			lastH = 0;
			return;
		}
		boolean panel = hasPanel() && background.value;
		int padX = panel ? 5 : 0;
		int padY = panel ? 3 : 0;
		int w = cw + padX * 2;
		int h = ch + padY * 2;
		lastW = w;
		lastH = h;

		int maxX = (int) (mc.getWindow().getGuiScaledWidth() - w * scale);
		int maxY = (int) (mc.getWindow().getGuiScaledHeight() - h * scale);
		x = Math.max(0, Math.min(x, maxX));
		y = Math.max(0, Math.min(y, maxY));

		g.pose().pushPose();
		g.pose().translate((float) x, (float) y, 0f);
		g.pose().scale(scale, scale, 1f);
		if (panel) {
			UI.roundRect(g, 0, 0, w, h, Theme.radius, Theme.panel());
			int r = Math.min(Theme.radius, h / 2);
			g.fill(0, r, 2, h - r, Theme.accent());
		}
		g.pose().translate((float) padX, (float) padY, 0f);
		drawContent(g, mc, font, cw, ch);
		g.pose().popPose();
	}
}
