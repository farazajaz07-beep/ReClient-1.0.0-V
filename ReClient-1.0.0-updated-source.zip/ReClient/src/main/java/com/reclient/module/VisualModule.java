package com.reclient.module;

import com.reclient.setting.BoolSetting;
import com.reclient.setting.SliderSetting;

/** Visual modules for HUD and PvP visuals. */
public final class VisualModule extends Module {
    public enum Kind { MOTION_BLUR, NO_OVERLAYS, CRYSTAL_OPTIMIZER }
    public final Kind kind;
    public final SliderSetting blurStrength;
    public final BoolSetting hideFire;
    public final BoolSetting hideShield;
    public final BoolSetting hideTotem;
    public final BoolSetting reduceParticles;

    public VisualModule(Kind kind) {
        super(switch (kind) {
            case MOTION_BLUR -> "Motion Blur (Experimental)";
            case NO_OVERLAYS -> "No Overlays";
            case CRYSTAL_OPTIMIZER -> "Crystal Optimizer";
        }, switch (kind) {
            case MOTION_BLUR -> "Experimental lightweight motion-trail setting; full-screen blur needs shader support.";
            case NO_OVERLAYS -> "Toggle fire, shield and totem visual suppression options.";
            case CRYSTAL_OPTIMIZER -> "Reduce particles for a lighter crystal PvP scene.";
        }, kind == Kind.MOTION_BLUR ? Category.HUD : Category.PVP);
        this.kind = kind;
        blurStrength = slider("Trail Strength", 2, 1, 5, 1);
        hideFire = bool("Hide Fire Overlay", true);
        hideShield = bool("Hide Shield Animation", true);
        hideTotem = bool("Hide Totem Pop", true);
        reduceParticles = bool("Reduce Particles", true);
        enabled = false;
    }

}
