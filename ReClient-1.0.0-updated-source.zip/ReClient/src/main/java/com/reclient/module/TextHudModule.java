package com.reclient.module;

import com.reclient.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** HUD element showing "label value", with the label in the accent colour. */
public abstract class TextHudModule extends HudModule {
	private String cached = "";

	protected TextHudModule(String name, String description, int x, int y) {
		super(name, description, x, y);
	}

	protected abstract String label();

	protected abstract String value(Minecraft mc);

	@Override
	protected int contentWidth(Minecraft mc, Font font) {
		cached = value(mc);
		return font.width(label()) + 4 + font.width(cached);
	}

	@Override
	protected int contentHeight(Minecraft mc, Font font) {
		return 8;
	}

	@Override
	protected void drawContent(GuiGraphics g, Minecraft mc, Font font, int w, int h) {
		String label = label();
		g.drawString(font, label, 0, 0, Theme.accent(), Theme.textShadow);
		g.drawString(font, cached, font.width(label) + 4, 0, 0xFFFFFFFF, Theme.textShadow);
	}
}
