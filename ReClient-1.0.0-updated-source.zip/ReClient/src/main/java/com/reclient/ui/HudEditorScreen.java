package com.reclient.ui;

import java.util.List;

import com.reclient.ReConfig;
import com.reclient.Theme;
import com.reclient.module.HudModule;
import com.reclient.module.ModuleManager;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Drag HUD modules around, scroll to resize, right-click to reset. */
public class HudEditorScreen extends Screen {
	private final Screen parent;
	private HudModule selected;
	private double offX, offY;
	private boolean dragging;

	public HudEditorScreen(Screen parent) {
		super(Component.literal("HUD Editor"));
		this.parent = parent;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		// custom background drawn in render()
	}

	private HudModule moduleAt(double mx, double my) {
		List<HudModule> list = ModuleManager.hud();
		for (int i = list.size() - 1; i >= 0; i--) {
			HudModule m = list.get(i);
			if (!m.enabled || m.lastW <= 0) continue;
			if (mx >= m.x && mx <= m.x + m.lastW * m.scale && my >= m.y && my <= m.y + m.lastH * m.scale) return m;
		}
		return null;
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		g.fill(0, 0, width, height, 0x70000000);

		if (dragging) {
			int accent = UI.alpha(Theme.accent(), 0.35f);
			g.fill(width / 2, 0, width / 2 + 1, height, accent);
			g.fill(0, height / 2, width, height / 2 + 1, accent);
		}

		for (HudModule m : ModuleManager.hud()) {
			if (!m.enabled) continue;
			m.render(g, minecraft, true);
			if (m.lastW <= 0) continue;
			boolean sel = m == selected;
			boolean hover = m == moduleAt(mouseX, mouseY);
			int x0 = m.x - 2, y0 = m.y - 2;
			int x1 = (int) (m.x + m.lastW * m.scale) + 2, y1 = (int) (m.y + m.lastH * m.scale) + 2;
			int c = sel ? Theme.accent() : hover ? 0xCCFFFFFF : 0x66FFFFFF;
			g.fill(x0, y0, x1, y0 + 1, c);
			g.fill(x0, y1 - 1, x1, y1, c);
			g.fill(x0, y0, x0 + 1, y1, c);
			g.fill(x1 - 1, y0, x1, y1, c);
			if (sel || hover) {
				g.pose().pushPose();
				g.pose().translate((float) x0, (float) (y0 - 8), 0f);
				g.pose().scale(0.75f, 0.75f, 1f);
				g.drawString(font, m.name, 0, 0, 0xFFFFFFFF, true);
				g.pose().popPose();
			}
		}

		String hint = "Drag to move   •   Scroll to resize   •   Right-click to reset   •   Esc to save";
		int hw = font.width(hint);
		UI.roundRect(g, (width - hw) / 2 - 8, height - 26, hw + 16, 18, 5, 0xCC0C0E12);
		g.drawString(font, hint, (width - hw) / 2, height - 21, 0xFFE8EAF0, false);
	}

	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		HudModule m = moduleAt(mx, my);
		selected = m;
		if (m == null) return super.mouseClicked(mx, my, button);
		if (button == 1) {
			m.resetPosition();
			ReConfig.save();
			return true;
		}
		if (button == 0) {
			dragging = true;
			offX = mx - m.x;
			offY = my - m.y;
		}
		return true;
	}

	@Override
	public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
		if (selected == null || button != 0 || !dragging) return super.mouseDragged(mx, my, button, dx, dy);
		double w = selected.lastW * selected.scale, h = selected.lastH * selected.scale;
		double nx = mx - offX, ny = my - offY;
		final double snap = 5;
		// snap to screen edges and centre
		if (Math.abs(nx) < snap) nx = 0;
		if (Math.abs(nx + w - width) < snap) nx = width - w;
		if (Math.abs(nx + w / 2 - width / 2.0) < snap) nx = width / 2.0 - w / 2;
		if (Math.abs(ny) < snap) ny = 0;
		if (Math.abs(ny + h - height) < snap) ny = height - h;
		if (Math.abs(ny + h / 2 - height / 2.0) < snap) ny = height / 2.0 - h / 2;
		selected.x = (int) Math.max(0, Math.min(nx, width - w));
		selected.y = (int) Math.max(0, Math.min(ny, height - h));
		return true;
	}

	@Override
	public boolean mouseReleased(double mx, double my, int button) {
		if (dragging) {
			dragging = false;
			ReConfig.save();
		}
		return super.mouseReleased(mx, my, button);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
		HudModule m = moduleAt(mx, my);
		if (m == null) m = selected;
		if (m == null) return super.mouseScrolled(mx, my, scrollX, scrollY);
		m.scale = Math.max(0.5f, Math.min(3f, Math.round((m.scale + (float) scrollY * 0.1f) * 10f) / 10f));
		ReConfig.save();
		return true;
	}

	@Override
	public void onClose() {
		ReConfig.save();
		minecraft.setScreen(parent);
	}
}
