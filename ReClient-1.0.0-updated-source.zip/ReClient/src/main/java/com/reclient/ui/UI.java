package com.reclient.ui;

import net.minecraft.client.gui.GuiGraphics;

/** Small drawing helpers (rounded rects, colour maths). */
public final class UI {
	private UI() {}

	public static void roundRect(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
		if ((color >>> 24) == 0 || w <= 0 || h <= 0) return;
		r = Math.min(r, Math.min(w, h) / 2);
		if (r <= 0) {
			g.fill(x, y, x + w, y + h, color);
			return;
		}
		g.fill(x, y + r, x + w, y + h - r, color);
		for (int i = 0; i < r; i++) {
			double dy = r - i - 0.5;
			int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
			g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
			g.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
		}
	}

	/** Multiply the alpha channel of an ARGB colour. */
	public static int alpha(int argb, float mul) {
		float m = Math.max(0f, Math.min(1f, mul));
		int a = (int) ((argb >>> 24) * m);
		return (a << 24) | (argb & 0xFFFFFF);
	}

	public static int lerpColor(int a, int b, float t) {
		t = Math.max(0f, Math.min(1f, t));
		int aa = (int) (((a >>> 24) & 255) + (((b >>> 24) & 255) - ((a >>> 24) & 255)) * t);
		int ar = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
		int ag = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
		int ab = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
		return (aa << 24) | (ar << 16) | (ag << 8) | ab;
	}
}
