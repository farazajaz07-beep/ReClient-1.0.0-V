package com.reclient;

/** Global look-and-feel settings shared by the menu and every HUD module. */
public final class Theme {
	public static float hue = 0.58f;
	public static float sat = 0.62f;
	public static boolean rainbow = false;
	public static int panelAlpha = 150; // 0..255, HUD background opacity
	public static boolean textShadow = true;
	public static int radius = 3; // corner roundness in px

	/** {hue, saturation} pairs for the swatches in the Theme tab. */
	public static final float[][] PRESETS = {
		{0.58f, 0.62f}, // blue
		{0.50f, 0.65f}, // cyan
		{0.38f, 0.60f}, // green
		{0.14f, 0.70f}, // yellow
		{0.07f, 0.75f}, // orange
		{0.00f, 0.70f}, // red
		{0.92f, 0.55f}, // pink
		{0.76f, 0.60f}, // purple
		{0.00f, 0.00f}, // white
	};

	private Theme() {}

	public static int accent() {
		float h = rainbow ? (System.currentTimeMillis() % 8000L) / 8000f : hue;
		return 0xFF000000 | hsv(h, sat, 1f);
	}

	public static int swatch(int i) {
		return 0xFF000000 | hsv(PRESETS[i][0], PRESETS[i][1], 1f);
	}

	/** HUD panel background colour with the configured opacity. */
	public static int panel() {
		return (panelAlpha << 24) | 0x0B0D12;
	}

	/** h, s, v in 0..1 -> 0xRRGGBB */
	public static int hsv(float h, float s, float v) {
		h = h - (float) Math.floor(h);
		float r, g, b;
		float f = h * 6f;
		int i = (int) Math.floor(f);
		f -= i;
		float p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
		switch (i % 6) {
			case 0 -> { r = v; g = t; b = p; }
			case 1 -> { r = q; g = v; b = p; }
			case 2 -> { r = p; g = v; b = t; }
			case 3 -> { r = p; g = q; b = v; }
			case 4 -> { r = t; g = p; b = v; }
			default -> { r = v; g = p; b = q; }
		}
		return ((int) (r * 255 + 0.5f) << 16) | ((int) (g * 255 + 0.5f) << 8) | (int) (b * 255 + 0.5f);
	}
}
